/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class WizAir extends AirPlaneCompany {

    public WizAir() {
        CompName = "Wiz Air";
        Symbol = "W6";
        AllFlights++;
    }

    public void CompInfo() {
        Window w = new Window(" Wiz Company", "C:\\Users\\msms1\\OneDrive\\Documents\\NetBeansProjects\\OOP\\src\\main\\java\\msg1541330102-31197 (1).jpg");
        w.setVisible(true);
    }
}

