/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author لميس
 */
public class Jazeera extends AirPlaneCompany {

    /**
     *
     */
    public Jazeera() {
        CompName = "Jazeera";
        Symbol = "J9";
        AllFlights++;
    }

    /**
     *
     */
    public void CompInfo() {
        Window w = new Window(" Jazeera Company", "C:\\Users\\msms1\\OneDrive\\Documents\\NetBeansProjects\\OOP\\src\\main\\java\\msg1541330102-31200 (1).jpg");
        w.setVisible(true);
    }
}

